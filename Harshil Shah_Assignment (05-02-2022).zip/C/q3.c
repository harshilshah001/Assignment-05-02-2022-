#include<stdio.h>

void main()
{
    int a[10]={1,5,4,8,9,2,0,6,11,7};
    int b,i,c=0;

    printf("Enter the element to be searched: ");
    scanf("%d", &b);

    for(i=0;i<10;i++){
        if(b==a[i]){
           ++c;
           break;
        }

    }
    if(c>0){
        printf("\nElement present at index %d\n",i);
    }
    else{
        printf("\nElement not found\n");
    }

    for(i=0;i<10;i++){
        printf("%d",a[i]);

    }

}
